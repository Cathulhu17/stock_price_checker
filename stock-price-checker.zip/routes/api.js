const express = require('express');
const axios = require('axios');
const bcrypt = require('bcrypt');
const mongoose = require('mongoose');

const router = express.Router();
const saltRounds = 10;

const stockSchema = new mongoose.Schema({
  symbol: { type: String, required: true },
  likes: { type: [String], default: [] }
});

const Stock = mongoose.model('Stock', stockSchema);

async function getStockData(symbol) {
  const url = `https://stock-price-checker-proxy.freecodecamp.rocks/v1/stock/${symbol}/quote`;
  const response = await axios.get(url);
  return {
    symbol: response.data.symbol,
    price: response.data.latestPrice
  };
}

router.get('/', async (req, res) => {
  try {
    let { stock, like } = req.query;
    if (!stock) return res.json({ error: 'Missing stock symbol' });

    const ip = req.ip || req.connection.remoteAddress;
    const hashedIp = bcrypt.hashSync(ip, saltRounds);

    if (typeof stock === 'string') stock = [stock];

    const stockData = await Promise.all(stock.map(async sym => {
      const { symbol, price } = await getStockData(sym.toUpperCase());

      let stockDoc = await Stock.findOne({ symbol });
      if (!stockDoc) stockDoc = new Stock({ symbol });

      if (like && !stockDoc.likes.includes(hashedIp)) {
        stockDoc.likes.push(hashedIp);
        await stockDoc.save();
      }

      return { symbol, price, likes: stockDoc.likes.length };
    }));

    if (stockData.length === 1) {
      res.json({ stockData: stockData[0] });
    } else {
      const relLikes = stockData.map((s, i) => ({
        symbol: s.symbol,
        price: s.price,
        rel_likes: s.likes - stockData[1 - i].likes
      }));
      res.json({ stockData: relLikes });
    }

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
